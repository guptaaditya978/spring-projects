package com.ibm;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.Beans.Car;
import com.ibm.Service.CarService;
import com.ibm.Service.LoginService;


@RestController
@RequestMapping("/index")
public class UserController {
	
	@Autowired
	LoginService lgService;
	
	@Autowired
	CarService carService;
	
	@GetMapping("/car")
    Iterable<Car> getCar(){
        return carService.getCars();
    }
	
	@PostMapping("/user")
	String login(int id, String password)
	{
		if(lgService.checkAvailability(id, password)==null) {
			return "Unsucessfull";
		}
		return "Succesfull";
	}
	
	@PostMapping("/car")
    void addCar(@RequestBody Car car) {
		carService.addCar(car);
    }
     
    @GetMapping("/car/{id}")
    Optional<Car> getCarById(@PathVariable int id) {
        return carService.getCarById(id);
    }
    
    @PutMapping("/car")
    void updateCar(@RequestBody Car user) {
    	carService.updateCar(user);
    }
    
    @DeleteMapping("/car/{id}")
    void deleteCar(@PathVariable int id) {
    	carService.deleteCar(id);
    }
	
}
