package com.ibm.Service;

import org.springframework.beans.factory.annotation.Autowired;

import com.ibm.Beans.User;
import com.ibm.Dao.LicenseRepository;

public class LicenseService {
	
	@Autowired
	LicenseRepository licenseRepo;
	
	void addLicense(User u) {
		licenseRepo.save(u);
	}
	
}
