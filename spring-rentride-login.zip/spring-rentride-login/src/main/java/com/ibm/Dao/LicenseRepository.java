package com.ibm.Dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ibm.Beans.User;


@Repository
public interface LicenseRepository extends CrudRepository<User, Integer>{
	
	
	
}
