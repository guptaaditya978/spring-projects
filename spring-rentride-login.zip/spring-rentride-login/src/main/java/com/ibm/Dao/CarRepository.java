package com.ibm.Dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ibm.Beans.Car;


@Repository
public interface CarRepository extends CrudRepository<Car, Integer>{

}
