package com.ibm.trainning;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/books")
public class BookInfoController {
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	BookService bookService;
	
	@RequestMapping("/{id}")
	public Book getBookInfo(@PathVariable int id) {
		return new Book("Alchemist","Book about life",5);
	}
	
	@RequestMapping("/all")
	List<Object> getAllBookData() {
		return bookService.getAllBookData();
	}
} 
