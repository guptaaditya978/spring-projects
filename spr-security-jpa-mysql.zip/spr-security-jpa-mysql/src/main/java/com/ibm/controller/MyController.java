package com.ibm.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.User;

@RestController
public class MyController {
	
	@CrossOrigin("http://localhost:4200")
	@RequestMapping("/")
	User getMessage() {
		return new User(1,"Aditya","asdasd");
	}
	
	@RequestMapping("/users")
	String getMesageForUsers() {
		return "Hello user, you are now logged in...";
	}
	
//	@PostMapping("/users")
//	String sendMessageasAdmin(String s)
//	{
//		return s;
//	}
	
	@RequestMapping("/admin")
	String getMessageForAdmin() {
		return "Hello Admin...";
	}
	@RequestMapping("/hr")
	String getMessageForHR() {
		return "Hello HR...";
	}
	@RequestMapping("/finance")
	String getMessageForFINANCE() {
		return "Hello FINANCE...";
	}
	@RequestMapping("/management")
	String getMessageForManagement() {
		return "You are in management team of the company...";
	}
	@RequestMapping("/developer")
	String getMessageForDeveloper() {
		return "Hello Developer...";
	}
}
