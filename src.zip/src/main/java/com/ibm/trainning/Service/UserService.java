package com.ibm.trainning.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.trainning.User;
import com.ibm.trainning.dao.UserDao;

@Service
public class UserService {

	@Autowired
	UserDao userDao;
	
	public User getUserById(int id) {
		return userDao.getUserById(id);
	}
	
	public List<User> getUsers(){
		return userDao.getUsers();
	}
	public void addUser(User u) {
		userDao.addUser(u);
	}
	public String updateUser(int id,User u) {
		return userDao.updateUser(id, u);
	}
	public String deleteUser(int id) {
		return userDao.deleteUser(id);
	}
	
}
