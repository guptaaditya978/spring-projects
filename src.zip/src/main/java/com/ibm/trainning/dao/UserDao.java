package com.ibm.trainning.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.ibm.trainning.User;

@Repository
public class UserDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public User getUserById(int id) {
		return jdbcTemplate.queryForObject("select * from userdetials where id=?", new Object[] {id},new UserMapper());
	}
	
	public List<User> getUsers(){
		return jdbcTemplate.query("select * from userdetials", new UserMapper());
	}
	public void addUser(User u) {
		jdbcTemplate.update("insert into userdetials values(?,?,?,?)", new Object[] {u.getId(),u.getName(),u.getNumber(),u.getAddress()});
	}
	public String updateUser(int id,User u) {
		if(jdbcTemplate.update("Update userdetials set name=?, number=?,address=? where id=?", new Object[] {u.getName(),u.getNumber(),u.getAddress(),u.getId()})>0) {
			return "Updated Sucessfully";
		}
		return "Not Updated";
	}
	public String deleteUser(int id) {
		if(jdbcTemplate.update("Delete from userdetials where id=?", new Object[] {id})>0) {
			return "Delete Sucessfully";
		}
		return "Not Deleted";
	}
	
	public class UserMapper implements RowMapper<User>{

		@Override
		public User mapRow(ResultSet rs, int rowNum) throws SQLException {
			// TODO Auto-generated method stub
			User u = new User();
			u.setId(rs.getInt("id"));
			u.setName(rs.getString("name"));
			u.setNumber(rs.getString("number"));
			u.setAddress(rs.getString("address"));
			return u;
		}
		
		
		
	}
	
	
	
}
