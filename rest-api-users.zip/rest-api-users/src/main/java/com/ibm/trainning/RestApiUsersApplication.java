package com.ibm.trainning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiUsersApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiUsersApplication.class, args);
	}

}
