package com.ibm.trainning.users;



public class UserController {
	
}
