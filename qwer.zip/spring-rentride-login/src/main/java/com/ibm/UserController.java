package com.ibm;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.Service.LoginService;

@RestController
@RequestMapping("index")
public class UserController {
	
	LoginService lgService;
	String login(int id, String password)
	{
		if(lgService.checkAvailability(id, password)==null) {
			return "Unsucessfull";
		}
		return "Succesfull";
	}
	
}
