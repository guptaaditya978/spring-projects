package com.ibm.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.ibm.Beans.User;

public interface UserRepository extends CrudRepository<User, Integer>{
	
	@Query(value = "select userName from user where id = :id && password = :password", nativeQuery = true)
    String checkAvailability(@Param(value = "id") int id,@Param(value = "password") String password);
}
