package com.ibm.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ibm.Dao.UserRepository;
import com.ibm.Beans.User;

public class LoginService {
	
	@Autowired
	UserRepository userRepo;
	
	
	public void addUser(User u) {
		userRepo.save(u);
	}
	public void updateUser(User u) {
		 userRepo.save(u);
	}
	public void deleteUser(int id) {
		userRepo.deleteById(id);
	}
	public String checkAvailability(int id,String password) {
		return userRepo.checkAvailability(id, password);
	}

}
