package com.ibm.trainning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiUserApplication.class, args);
	}

}
