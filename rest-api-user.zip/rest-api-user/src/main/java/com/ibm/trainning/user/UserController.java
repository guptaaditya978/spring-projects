package com.ibm.trainning.user;
import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
	
	ArrayList<Cars> cars= new ArrayList<>(Arrays.asList(
			new Cars(101,"Alto","Maruti Suzuki"),
			new Cars(102,"Polo","Volkswagon"),
			new Cars(103,"Duster","Renault"),
			new Cars(104,"Creta","Hundai")
			));
	
	
	@RequestMapping("/cars")
	public ArrayList<Cars> getAllCarDetails(){
		return cars;
	}
	@GetMapping("/cars/{id}")
	public Cars getDetailById(@PathVariable int id) {
		for(Cars c :cars) {
			if(c.getId().equals(id)) {
				return c;
			}
		}
		return null;
	}
	@PostMapping("/cars")
	
	public String addCar(@RequestBody Cars car) {
		cars.add(car);
		return "Added Sucessfully";
	}
	
	@PutMapping("/cars/{id}")
	public String updateCar(@PathVariable int id ,@RequestBody Cars car) {
		for(Cars c: cars) {
			if(c.getId().equals(id)) {
				cars.set(cars.indexOf(c), car);
			}
		}
		return "Updated Sucessfully";
	}
	@DeleteMapping("/cars/{id}")
	public String deleteCar(@PathVariable int id) {
		Cars temp=null;
		for(Cars c: cars) {
			if(c.getId().equals(id)) {
				temp=c;
				break;
			}
		}
		//System.out.println(temp.getName());
		cars.remove(temp);
		//System.out.println(cars);
		return "Deleted Sucessfully";
	}
}
