package com.ibm.trainning;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("index")
public class UserController {
	
	@GetMapping("/greeting")
	public String getusers() {
		return "Hey there";
	}
	@RequestMapping("/users")
	String getUserData() {
		return "Hello User, Welcome to our Application...";
	}
	
	@RequestMapping("/admin")
	String getAdminData() {
		return "Hey Admin...";
	}
	
	@RequestMapping("/")
	String getPublicData() {
		return "This are is open to everyone, requires no authentication...";
	}
	
}
