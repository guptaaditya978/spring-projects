package com.ibm.trainning;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		Setting the configuration on the authentication object

		auth.inMemoryAuthentication().withUser("ibm").password("ibm").roles("USER") // ROLE_USER
				.and().withUser("ibmAdmin").password("admin").roles("ADMIN"); // ROLE_ADMIN

	}

//	For Authorization:

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().antMatchers("/index/admin").hasRole("ADMIN").antMatchers("/index/users")
				.hasAnyRole("USER", "ADMIN").antMatchers("/").permitAll().and().formLogin();
	}

//	Get a PasswordEncoder
	@SuppressWarnings("deprecation")
	@Bean
	PasswordEncoder getPasswordEncoder() {
		return NoOpPasswordEncoder.getInstance();
	}
}
