package com.ibm.bootinit;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/app")
public class Menu {
	
	@RequestMapping("/greeting")
	public String getName() {
		return "Badhiya.....";
	}
	
}
