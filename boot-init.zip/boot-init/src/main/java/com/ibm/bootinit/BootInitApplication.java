package com.ibm.bootinit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootInitApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootInitApplication.class, args);
	}

}
