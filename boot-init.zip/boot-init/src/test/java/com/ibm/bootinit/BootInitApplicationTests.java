package com.ibm.bootinit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootInitApplicationTests {

	@Test
	void contextLoads() {
	}

}
