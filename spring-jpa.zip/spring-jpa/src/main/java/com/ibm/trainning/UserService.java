package com.ibm.trainning;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	@Autowired
	UserRepository userRepo;
	
	public Optional<User> getUserById(int id) {
		return userRepo.findById(id);
	}
	
	public List<User> getUsers(){
		return (List<User>) userRepo.findAll();
	}
	public void addUser(User u) {
		userRepo.save(u);
	}
	public void updateUser(User u) {
		 userRepo.save(u);
	}
	public void deleteUser(int id) {
		userRepo.deleteById(id);
	}
	public Optional<User> getUserByName(String name) {
		return userRepo.findByName(name);
	}
	
}
