package com.ibm.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.Dao.CarRepository;
import com.ibm.Beans.Car;

@Service
public class CarService {
	
	@Autowired
	CarRepository carRepository;
	
	public Optional<Car> getCarById(int car_id) {
		return carRepository.findById(car_id);
	}
	
	public  void addCar(Car c) {
		carRepository.save(c);
	}
	public void updateCar(Car u) {
		carRepository.save(u);
	}
	public void deleteCar(int car_id) {
		carRepository.deleteById(car_id);
	}
}
