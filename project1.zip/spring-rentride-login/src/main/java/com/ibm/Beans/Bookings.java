package com.ibm.Beans;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Bookings {

	@Id
	Integer book_id;
	
	Date start_date, end_date;
	
	Integer car_id, user_id;
	
	Boolean status;
	
	String pick_location, drop_location;

	public Integer getBook_id() {
		return book_id;
	}

	public void setBook_id(Integer book_id) {
		this.book_id = book_id;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public Integer getCar_id() {
		return car_id;
	}

	public void setCar_id(Integer car_id) {
		this.car_id = car_id;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getPick_location() {
		return pick_location;
	}

	public void setPick_location(String pick_location) {
		this.pick_location = pick_location;
	}

	public String getDrop_location() {
		return drop_location;
	}

	public void setDrop_location(String drop_location) {
		this.drop_location = drop_location;
	}
	
	
}