package com.ibm.trainning;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("catalog")
public class BookCatalogController {
	
//	@RequestMapping("/message")
//	String getMessage() {
//		return "we are about to do microservices...";
//	}
//	
	@RequestMapping("/all")
	List<BookCatalogItem> getBookData() {
		return  Arrays.asList(
				new BookCatalogItem("Alchemist", "A book about life", 5),
				new BookCatalogItem("Glory of Cricket", "A book about sports", 4),
				new BookCatalogItem("2 States", "A book about romance", 3),
				new BookCatalogItem("Dairy of a Wimpy Kid", "A book fro children", 5)
				);
	}
	
}
